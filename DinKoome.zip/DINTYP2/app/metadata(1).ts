export const metadata = {
  title: "AI Character Explorer",
  description: "Explore and chat with AI characters",
}
