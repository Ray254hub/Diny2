// The rest of the original code would go here.  Since it was omitted, I cannot provide a complete merged file.
// However, the core issue of the undeclared variables is addressed with the import statement above.
