Admin credentials for development:
Username: Raymond
Password: RAYMOND123!

Use the API /api/dev-admin-login to set a dev cookie for testing.
Do NOT use dev bypass in production. Follow scripts/SEED_ADMIN_INSTRUCTIONS.sql to seed admin in Supabase.
