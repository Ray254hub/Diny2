# Deployment Instructions (Final)

1. Go to https://vercel.com → New Project → Import from GitHub (or Upload).
2. Ensure Root Directory = project root (contains package.json, next.config.js).
3. Add Environment Variables (from .env.local) in Vercel dashboard.
4. Connect to Supabase project (auth + DB + storage).
5. Enable Stripe webhook → point to https://yourdomain/api/stripe/webhook.
6. For Sandbox testing → replace Stripe keys with test keys (sk_test..., pk_test...).
7. Run `scripts/SEED_ADMIN_INSTRUCTIONS.sql` in Supabase SQL editor to seed admin user.
8. Access Admin Panel → /admin (login with seeded user).

Dev Admin Bypass (for testing only):
POST /api/dev-admin-login { "username":"Raymond", "password":"RAYMOND123!" }
