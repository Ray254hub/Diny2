export default function Page() {
  return (
    <main className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold">Test post 3</h1>
      <p className="mt-4">Detta är ett testinlägg nummer 3.</p>
    </main>
  )
}
