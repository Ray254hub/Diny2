"use client";

import CreateCharacterFlow from "@/components/skapa-flickvän-flow";

export default function CreateCharacterPage() {
    return <CreateCharacterFlow />;
}
