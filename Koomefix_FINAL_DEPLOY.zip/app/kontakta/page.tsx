export default function Page() {
  return (
    <main className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold">Kontakta oss</h1>
      <p className="mt-4">Detta är sidan för Kontakta oss. Innehåll ska fyllas enligt kunddokument.</p>
    </main>
  )
}
