export default function AffiliateLayout({ children }: { children: React.ReactNode }) {
    return <div>{children}</div>
}