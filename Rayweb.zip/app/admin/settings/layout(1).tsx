import type { ReactNode } from "react"

export default function AdminSettingsLayout({ children }: { children: ReactNode }) {
  return <>{children}</>
}
