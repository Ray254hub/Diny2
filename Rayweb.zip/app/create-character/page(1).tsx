"use client";

import CreateCharacterFlow from "@/components/create-character-flow";

export default function CreateCharacterPage() {
    return <CreateCharacterFlow />;
}
